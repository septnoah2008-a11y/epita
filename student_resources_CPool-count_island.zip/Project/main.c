#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int count_island(char **world);

static char **get_world(FILE *map)
{
    size_t len = 0;
    ssize_t n;
    char *line = NULL;
    char **world;
    int nb_lines;
    size_t world_size;

    n = getline(&line, &len, map);
    if (n == -1) {
        free(line);
        return (NULL);
    }
    nb_lines = atoi(line);
    free(line);
    if (nb_lines < 0)
        return (NULL);
    world_size = (nb_lines + 1) * sizeof(*world);
    world = malloc(world_size);
    if (!world)
        return (NULL);
    memset(world, 0, world_size);
    for (int i = 0; i < nb_lines; i++) {
        len = 0;
        n = getline(world + i, &len, map);
        if (n == -1)
            break;
        if (world[i][n - 1] == '\n')
            world[i][n - 1] = '\0';
    }
    return (world);
}

static void free_world(char **world)
{
    for (int i = 0; world[i]; i++) {
        free(world[i]);
    }
    free(world);
}

static void display_world(char **world)
{
    for (int i = 0; world[i]; i++)
        printf("%s\n", world[i]);
}

int main(int ac, char **av)
{
    FILE *map;
    char **world;
    int nb_islands;

    if (ac < 2) {
        fprintf(stderr, "Usage: %s <map_file>\n", av[0]);
        return (1);
    }
    map = fopen(av[1], "r");
    if (!map) {
        fprintf(stderr, "Error: cannot open map file '%s'\n", av[1]);
        return (1);
    }
    world = get_world(map);
    fclose(map);
    if (!world) {
        fprintf(stderr, "Error: invalid map file '%s'\n", av[1]);
        return (1);
    }
    nb_islands = count_island(world);
    display_world(world);
    printf("Number of islands found: %d\n", nb_islands);
    free_world(world);
    return (0);
}
